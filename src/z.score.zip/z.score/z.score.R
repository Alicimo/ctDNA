# sWG data - Script for Meiling
# loads poseidon data and generates genome z scores for each segmentation
# author: Alistair Martin
# date: 30th Aug 2017

library(data.table)
load("poseidon.Rdata")
load("poseidon.RECIST.Rdata")

#threshold points below -3 as these heavuly influence the genome wide measures if unchanged
data$cns <- cbind(data$cns[,1:4,with=F],apply(data$cns[,-(1:4)],2,function(x){x[x < -3] <- -3; x}))
data$segments <- cbind(data$segments[,1:4,with=F],apply(data$segments[,-(1:4)],2,function(x){x[x < -3] <- -3; x}))

get.z.score <- function(){
  #calculate population distrubrution for each bin
  i <- data$meta[,which(type=="BC")]
  s <- apply(2^data$cns[,i+4,with=F],1,function(x){sd(x,na.rm=T)})
  u  <- rowSums(2^data$cns[,i+4,with=F]) / length(i)
  
  #for each sample, calculate genome z.score
  x <- as.data.table(cbind(
    data$meta[,.(Sample.name,type,patient,cycle,total.days)],
    data$cns[,.(z=sapply(.SD[,-(1:4)],function(x){sum(((as.numeric(2^x)-u)/s)^2,na.rm=T)}))]
  ))
  x
}

z.scores <- get.z.score()